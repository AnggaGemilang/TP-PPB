# Asset Licenses

The licenses for the asset files included in this demo can be found below.

## test.png

Retrieved from [https://www.ars.usda.gov/oc/images/photos/jun04/k11252-1/](https://www.ars.usda.gov/oc/images/photos/jun04/k11252-1/) on 28 April 2018.

Photo courtesy of USDA Agricultural Research Service

Photos in our Image Gallery are available free of charge and are copyright-free, public domain, images unless otherwise indicated.

Please note: these photos may not be used to infer or imply ARS endorsement of any product, company, or position.

When using these photos, we ask that you credit the Agricultural Research Service. You may use one of the following credit lines:

Photo by (photographer's name), USDA Agricultural Research Service.
Photo courtesy of USDA Agricultural Research Service.
Photo courtesy of USDA ARS.